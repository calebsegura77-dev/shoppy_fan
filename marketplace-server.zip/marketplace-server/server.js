const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const PUERTO = process.env.PORT || 3000;
const COMISION_PORCENTAJE = 0.05; // 5% de comisión de la plataforma

// ---------- RUTAS DE DATOS (archivos JSON como base de datos simple) ----------
const RUTA_PRODUCTOS = path.join(__dirname, 'data', 'productos.json');
const RUTA_USUARIOS = path.join(__dirname, 'data', 'usuarios.json');
const RUTA_VENTAS = path.join(__dirname, 'data', 'ventas.json');
const RUTA_UPLOADS = path.join(__dirname, 'uploads');

function leerJSON(ruta) {
  try {
    return JSON.parse(fs.readFileSync(ruta, 'utf-8'));
  } catch {
    return [];
  }
}
function guardarJSON(ruta, datos) {
  fs.writeFileSync(ruta, JSON.stringify(datos, null, 2));
}

// ---------- MIDDLEWARES ----------
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(RUTA_UPLOADS));

app.use(session({
  secret: process.env.SESSION_SECRET || 'cambia-este-secreto-en-produccion',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge: 1000 * 60 * 60 * 24 // 24 horas
  }
}));

// Subida de imágenes: se guardan en disco, no en la base de datos
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, RUTA_UPLOADS),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.round(Math.random() * 1e6)}${ext}`);
  }
});
const tiposPermitidos = ['.jpg', '.jpeg', '.png', '.webp', '.gif'];
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB máx
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, tiposPermitidos.includes(ext));
  }
});

function requiereSesion(req, res, next) {
  if (!req.session.usuario) {
    return res.status(401).json({ error: 'Debes iniciar sesión.' });
  }
  next();
}
function requiereVendedor(req, res, next) {
  if (!req.session.usuario || req.session.usuario.tipo !== 'vendedor') {
    return res.status(403).json({ error: 'Solo cuentas de vendedor pueden publicar productos.' });
  }
  next();
}

// ---------- AUTENTICACIÓN ----------
app.post('/api/registro', async (req, res) => {
  const { email, password, tipo } = req.body;
  if (!email || !password || password.length < 6) {
    return res.status(400).json({ error: 'Correo y contraseña (mínimo 6 caracteres) son obligatorios.' });
  }
  const usuarios = leerJSON(RUTA_USUARIOS);
  if (usuarios.find(u => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(409).json({ error: 'Ese correo ya está registrado.' });
  }
  const hash = await bcrypt.hash(password, 10);
  const nuevoUsuario = {
    id: Date.now(),
    email,
    password: hash,
    tipo: tipo === 'vendedor' ? 'vendedor' : 'comprador',
    verificado: false,
    cedula: null
  };
  usuarios.push(nuevoUsuario);
  guardarJSON(RUTA_USUARIOS, usuarios);

  req.session.usuario = { id: nuevoUsuario.id, email: nuevoUsuario.email, tipo: nuevoUsuario.tipo, verificado: false };
  res.json({ ok: true, usuario: req.session.usuario });
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const usuarios = leerJSON(RUTA_USUARIOS);
  const usuario = usuarios.find(u => u.email.toLowerCase() === (email || '').toLowerCase());
  if (!usuario || !(await bcrypt.compare(password || '', usuario.password))) {
    return res.status(401).json({ error: 'Correo o contraseña incorrectos.' });
  }
  req.session.usuario = { id: usuario.id, email: usuario.email, tipo: usuario.tipo, verificado: usuario.verificado };
  res.json({ ok: true, usuario: req.session.usuario });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/sesion', (req, res) => {
  res.json({ usuario: req.session.usuario || null });
});

// Verificación de edad / cédula
app.post('/api/verificar', requiereSesion, (req, res) => {
  const { cedula } = req.body;
  if (!/^[0-9]{10}$/.test(cedula || '')) {
    return res.status(400).json({ error: 'La cédula debe tener 10 dígitos.' });
  }
  const usuarios = leerJSON(RUTA_USUARIOS);
  const usuario = usuarios.find(u => u.id === req.session.usuario.id);
  usuario.cedula = cedula;
  usuario.verificado = true;
  guardarJSON(RUTA_USUARIOS, usuarios);
  req.session.usuario.verificado = true;
  res.json({ ok: true });
});

// ---------- PRODUCTOS ----------
app.get('/api/productos', (req, res) => {
  const { buscar } = req.query;
  let productos = leerJSON(RUTA_PRODUCTOS);
  if (buscar) {
    const q = buscar.toLowerCase();
    productos = productos.filter(p => p.titulo.toLowerCase().includes(q));
  }
  res.json(productos);
});

app.post('/api/productos', requiereVendedor, upload.single('foto'), (req, res) => {
  const { titulo, precio, categoria } = req.body;
  const precioNum = parseFloat(precio);
  if (!titulo || !precioNum || precioNum <= 0) {
    return res.status(400).json({ error: 'Título y precio válido son obligatorios.' });
  }
  if (!req.file) {
    return res.status(400).json({ error: 'La foto es obligatoria.' });
  }
  const productos = leerJSON(RUTA_PRODUCTOS);
  const nuevoProducto = {
    id: Date.now(),
    titulo,
    precio: precioNum,
    categoria: categoria || 'General',
    vendedor: req.session.usuario.email,
    imagen: `/uploads/${req.file.filename}`
  };
  productos.unshift(nuevoProducto);
  guardarJSON(RUTA_PRODUCTOS, productos);
  res.json({ ok: true, producto: nuevoProducto });
});

// ---------- PAGO / COMISIÓN ----------
// El desglose se calcula SIEMPRE en el servidor (nunca confiar en números que mande el navegador)
app.post('/api/pago', requiereSesion, (req, res) => {
  const { productoId } = req.body;
  const productos = leerJSON(RUTA_PRODUCTOS);
  const producto = productos.find(p => p.id === productoId);
  if (!producto) return res.status(404).json({ error: 'Producto no encontrado.' });

  const comision = Math.round(producto.precio * COMISION_PORCENTAJE * 100) / 100;
  const pagoVendedor = Math.round((producto.precio - comision) * 100) / 100;

  const venta = {
    id: Date.now(),
    productoId: producto.id,
    titulo: producto.titulo,
    comprador: req.session.usuario.email,
    vendedor: producto.vendedor,
    precioTotal: producto.precio,
    comision,
    pagoVendedor,
    fecha: new Date().toISOString()
  };
  const ventas = leerJSON(RUTA_VENTAS);
  ventas.push(venta);
  guardarJSON(RUTA_VENTAS, ventas);

  res.json({ ok: true, venta });
});

app.listen(PUERTO, () => {
  console.log(`✅ Servidor corriendo en http://localhost:${PUERTO}`);
});
