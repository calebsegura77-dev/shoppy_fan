# Plataforma Comercial CM — Servidor

## Requisitos
- Node.js 18 o superior instalado en tu computadora.

## Instalación y arranque
```bash
cd marketplace-server
npm install
npm start
```
Luego abre en el navegador: **http://localhost:3000**

## Qué cambió respecto a la versión anterior (solo HTML)
1. **Backend real (Express)**: los productos, usuarios y ventas ya no viven en el
   `localStorage` del navegador — se guardan en el servidor, en `data/*.json`.
   Cualquier persona que entre a la página ve el mismo catálogo.
2. **Contraseñas con hash (bcrypt)**: antes no existía ni una contraseña real;
   ahora se registran cuentas de verdad y las contraseñas nunca se guardan en texto plano.
3. **Sesiones con cookies seguras** (`express-session`) en vez de simular el login
   con una variable de JavaScript que se perdía al recargar la página.
4. **Fotos guardadas en disco** (`/uploads`) en vez de convertidas a base64 gigante
   dentro del `localStorage`, que se llenaba rápido y volvía lenta la página.
5. **La comisión del 5% se calcula en el servidor**, no en el navegador — así nadie
   puede manipular el desglose del pago desde las herramientas de desarrollador.
6. Categoría de producto, búsqueda con "debounce" (no dispara una búsqueda por
   cada tecla) y mensajes de error visibles en los formularios.

## Siguientes pasos recomendados (no incluidos aquí)
- Integrar un procesador de pagos real (Stripe/PayPal) para el cobro con tarjeta;
  ahora mismo el botón de "Pagar" solo registra la venta y simula el resultado.
- Cambiar los archivos JSON por una base de datos real (PostgreSQL, MongoDB) si
  esperas mucho tráfico o muchos vendedores.
- Cambiar `SESSION_SECRET` por un valor secreto propio antes de publicar en producción,
  usando una variable de entorno: `SESSION_SECRET=algo-largo-y-aleatorio npm start`.
- Servir el sitio detrás de HTTPS si lo vas a exponer en internet.
